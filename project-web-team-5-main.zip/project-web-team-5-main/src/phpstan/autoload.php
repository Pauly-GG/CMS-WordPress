<?php
/**
 * Load PHPStan extensions
 *
 * @package Understrap
 */

require_once __DIR__ . '/GetThemeModReturnType.php';
